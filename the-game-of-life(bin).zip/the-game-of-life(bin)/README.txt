Copyright (c) 2021, by Marc Oliveras
Website: http://oligalma.com
Email: admin@oligalma.com

You can open and run the program with Eclipse --> http://eclipse.org

To run the program without Eclipse: java -jar the-game-of-life.jar
